# hpm/hpm/config.py

# الإعدادات العامة للمشروع
DRY_RUN_MODE = False
LOG_LEVEL = "INFO"
